### Name: plot.bfast
### Title: Methods for objects of class "bfast".
### Aliases: plot.bfast
### Keywords: ts

### ** Examples

## See 'bfast' for examples.



