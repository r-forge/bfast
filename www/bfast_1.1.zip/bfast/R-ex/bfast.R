### Name: bfast
### Title: Break detection in the seasonal and trend component of a
###   univariate time series
### Aliases: bfast
### Keywords: ts

### ** Examples

# Simulated Data
plot(simts) # stl object containing simulated NDVI time series

datats <- ts(rowSums(simts$time.series)) # sum of all the components (season,abrupt,remainder)
tsp(datats) <- tsp(simts$time.series) # assign correct time series attributes
plot(datats)

fit <- bfast(datats,h=0.15,max.iter=1)
plot(fit,sim=simts)

fit # prints out whether breakpoints are detected in the seasonal and trend component

# Real data
# The data should be a regular ts() object without NA's
# See Fig. 8 b in reference
plot(harvest, ylab='NDVI') # MODIS 16-day cleaned and interpolated NDVI time series 

fit <- bfast(harvest,h=0.15,max.iter=1,breaks=2)
plot(fit)
plot(fit,type="trend",largest=TRUE)
plot(fit,type="all") 




