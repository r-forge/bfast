### Name: simts
### Title: Simulated seasonal 16-day NDVI time series
### Aliases: simts
### Keywords: datasets

### ** Examples

plot(simts)



